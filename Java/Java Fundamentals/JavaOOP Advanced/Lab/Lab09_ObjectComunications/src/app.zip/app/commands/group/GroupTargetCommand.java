package app.commands.group;

import app.commands.Command;
import app.mediator.AttackGroup;
import app.models.Target;

public class GroupTargetCommand implements Command{

    private Target target;
    private AttackGroup group;

    public GroupTargetCommand( AttackGroup group, Target target) {
        this.target = target;
        this.group = group;
    }

    @Override
    public void execute() {
        group.groupTarget(this.target);
    }
}
