package app.models;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}