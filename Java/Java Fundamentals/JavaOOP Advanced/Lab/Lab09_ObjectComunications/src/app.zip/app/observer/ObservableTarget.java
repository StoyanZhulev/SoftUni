package app.observer;

import app.models.Target;

public interface ObservableTarget extends Target, Observer{

}
