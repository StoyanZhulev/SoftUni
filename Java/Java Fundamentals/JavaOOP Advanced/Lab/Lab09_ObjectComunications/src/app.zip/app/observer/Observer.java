package app.observer;

public interface Observer {
    void update(int value);
}
