package app.commands;

public interface Command {
    void execute();
}
