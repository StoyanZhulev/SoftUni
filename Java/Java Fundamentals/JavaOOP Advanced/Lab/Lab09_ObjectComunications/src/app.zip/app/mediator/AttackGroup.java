package app.mediator;


import app.models.Attacker;
import app.models.Target;

public interface AttackGroup {
    void addMember(Attacker attacker);

    void groupTarget(Target target);

    void groupAttack();
}
