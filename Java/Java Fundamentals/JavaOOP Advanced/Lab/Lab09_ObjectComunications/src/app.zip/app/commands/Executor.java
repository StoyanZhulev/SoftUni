package app.commands;

public interface Executor {
    void executeCommand(Command command);
}
